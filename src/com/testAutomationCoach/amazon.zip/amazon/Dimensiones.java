package com.testAutomationCoach.amazon;

public class Dimensiones {
    double x;
    double y;
}
