package com.testAutomationCoach.amazon;

public class Image {

    String textoImagen;
    String tooltip;
    String piedeImagen;
    String link;
    String href;




}
