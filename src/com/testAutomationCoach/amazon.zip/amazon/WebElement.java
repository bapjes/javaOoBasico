package com.testAutomationCoach.amazon;

public class WebElement {

    Ubicacion ubicacion;
    Boolean estaHabilitado;
    Boolean estaVisible;
    Dimensiones dimensiones;

    public void click()
    {

    }

    public void mouseOver()
    {

    }

    public void cambiarUbicacion(Ubicacion u)
    {

    }

    public void cambiarDmensiones(Dimensiones d)
    {

    }


    public void rightClick() {

    }
}
