package com.testAutomationCoach.amazon;

public class TextField {
    String color;
    String colorFondo;
    String fuente;
    double tamanoFuente;
    String placeholder;
    int capacidadCaracteres;

    public void ingresarTexto(String producto) {
        System.out.println("Verificar que la caja de texto  exista ");
        System.out.println("Pasarle el texto  '" + producto + "' a la caja de texto");
    }

    public void borrarTexto() {

    }


}
