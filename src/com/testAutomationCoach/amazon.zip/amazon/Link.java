package com.testAutomationCoach.amazon;

public class Link {

    String texto;
    String colorLink;
    String hipervinculo;



}
