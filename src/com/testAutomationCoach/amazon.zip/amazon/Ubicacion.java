package com.testAutomationCoach.amazon;

public class Ubicacion {

    double ubicacionX;
    double ubicacionY;
}
